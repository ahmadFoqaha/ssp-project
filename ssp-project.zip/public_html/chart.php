<!DOCTYPE html>
<html>
  <head>
    <title>Google Chart</title>
    <!-- Include Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Genre', 'Number of Books'],
          <?php
          // Include database connection file
          include "db_connection.php";

          // Query to retrieve data from database
          $sql = "SELECT genre, COUNT(*) AS count FROM books GROUP BY genre";
          $result = mysqli_query($conn, $sql);

          // Loop through the query result and generate chart data
          while($row = mysqli_fetch_assoc($result)) {
            echo "['" . $row['genre'] . "', " . $row['count'] . "],";
          }
          ?>
        ]);

        var options = {
          title: 'Books by Genre',
          pieHole: 0.4,
        };

        var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
     <!-- Navigation Bar -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<a class="navbar-brand" href="#">Online Library</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link" href="index.php">Home</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="add_book.php">Add New Book</a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="chart.php">Chart</a>
				</li>
			</ul>
		</div>
	</nav>
    <div id="chart_div" style="width: 900px; height: 500px;"></div>
    
    	<!-- Include Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  </body>
</html>

<!DOCTYPE html>
<html>
<head>
	<title>Online Library</title>
	<!-- Include Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>

	<!-- Navigation Bar -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<a class="navbar-brand" href="#">Online Library</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
				<li class="nav-item active">
					<a class="nav-link" href="index.php">Home</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="add_book.php">Add New Book</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="chart.php">Chart</a>
				</li>
			</ul>
		</div>
	</nav>

	<!-- Container to Display Books -->
	<div class="container mt-5">
		<div class="row">
				<?php
				// Include database connection
				include('db_connection.php');

				// Select all books from the 'books' table
				$sql = "SELECT * FROM books";
				$result = mysqli_query($conn, $sql);

				// Loop through the results and display each book
				while($row = mysqli_fetch_assoc($result)) {
					echo '<div class="col-md-3 mb-3">';
					echo '<div class="card">';
					echo '<img src="/img/'.$row['image'].'" class="card-img-top" alt="Book Cover">';
					echo '<div class="card-body">';
					echo '<h5 class="card-title">'.$row['title'].'</h5>';
					echo '<p class="card-text">'.$row['author'].'</p>';
					echo '<p class="card-text">'.$row['genre'].'</p>';
					echo '<p class="card-text">'.$row['description'].'</p>';
					echo '<p class="card-text">'.$row['year'].'</p>';
					echo '<a href="edit_book.php?id='.$row['id'].'" class="btn btn-primary mr-2">Edit</a>';
					echo '<a href="delete_book.php?id='.$row['id'].'" class="btn btn-danger">Delete</a>';
					echo '</div>';
					echo '</div>';
					echo '</div>';
				}

				// Close database connection
				mysqli_close($conn);
				?>
			</div>
		</div>

	<!-- Include Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>

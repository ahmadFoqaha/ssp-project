<?php

// Database credentials
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'id20756779_admin');
define('DB_PASSWORD', '3@<}RS)x*c[Fz9]p');
define('DB_NAME', 'id20756779_library');

// Create database connection
$conn = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check database connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>

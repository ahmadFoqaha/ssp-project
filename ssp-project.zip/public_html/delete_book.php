<!DOCTYPE html>
<html>
<head>
	<title>Delete Book</title>
	<!-- Include Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
	<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<a class="navbar-brand" href="#">Online Library</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="navbarNav">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link" href="index.php">Home</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="add_book.php">Add New Book</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="chart.php">Chart</a>
			</li>
		</ul>
	</div>
</nav>

<!-- Container to Delete Book -->
<div class="container mt-5">
	<div class="row">
			<div class="col-md-12">
				<h2>Delete Book</h2>
				<?php
					// Include database connection file
					include "db_connection.php";
					
					// Get book id from URL
					$id = $_GET['id'];
					
					// Delete book from database
					$sql = "DELETE FROM books WHERE id = '$id'";
					if (mysqli_query($conn, $sql)) {
						echo "Book deleted successfully.";
					} else {
						echo "Error deleting book: " . mysqli_error($conn);
					}
				?>
			</div>
		</div>
</div>

<!-- Include Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
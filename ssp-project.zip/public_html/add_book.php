<!DOCTYPE html>
<html>
<head>
	<title>Add New Book</title>
	<!-- Include Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>

	<!-- Navigation Bar -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<a class="navbar-brand" href="#">Online Library</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link" href="index.php">Home</a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="add_book.php">Add New Book</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="chart.php">Chart</a>
				</li>
			</ul>
		</div>
	</nav>
<?php
// Include database connection file
include "db_connection.php";

// Function to convert a string to snake case
function snake_case($str)
{
    $str = strtolower($str);
    $str = str_replace(" ", "_", $str);
    return $str;
}

// Check if form is submitted
if (isset($_POST["submit"])) {
    // Get form data
    $title = $_POST["title"];
    $author = $_POST["author"];
    $genre = $_POST["genre"];
    $description = $_POST["description"];
    $year = $_POST["year"];

    // Convert book title to snake case
    $image_name = snake_case($title);

    // Upload book image to root folder
    $target_dir = "img/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $new_image_name = $image_name . "." . $imageFileType;
    $target_file = $target_dir . $new_image_name;
    move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);

    // Insert book data into database
    $sql = "INSERT INTO books (title, author, genre, description, year, image) VALUES ('$title', '$author', '$genre', '$description', '$year', '$new_image_name')";
    if (mysqli_query($conn, $sql)) {
        echo "Book Added Successfully";
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!-- HTML form to add a new book -->
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <h2>Add New Book</h2>
            <form method="post" action="" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Author</label>
                    <input type="text" name="author" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Genre</label>
                    <input type="text" name="genre" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control"></textarea>
                </div>
                <div class="form-group">
                    <label>Year</label>
                    <input type="number" name="year" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Image</label>
                    <input type="file" name="image" class="form-control-file" required>
                    <input type="hidden" name="image_name" value="<?php echo $image_name; ?>">
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>

	</div>
	
	<!-- Include Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>